# @mini-figma/vite

Development-only visual inspection and design-intent editing for an existing React/Vite application.

The plugin instruments the application's JSX during `vite serve`, injects an in-page picker, and hosts a same-origin studio at `/__mini-figma/`. Preview edits are reversible overrides; the plugin does not continuously rewrite source.

> 0.1.0 is an unpublished development version. The package name is a working name.

## Install

After this package is published:

```sh
npm install --save-dev @mini-figma/vite
```

For the current repository, build and install a local `npm pack` tarball instead.

The package declares Vite `>=6 <9` as a peer dependency. The repository currently verifies React 19.2 and Vite 8.2; the broader matrix is not yet tested.

## Configure

```ts
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";
import { miniFigma } from "@mini-figma/vite";

export default defineConfig({
  plugins: [react(), miniFigma()],
});
```

Run the normal development command. Click the small Mini Figma icon in the lower-right corner, then click a source-mapped component. Its isolated editor opens automatically in a nearly full-screen modal.

The plugin declares `apply: "serve"`; its transform, routes, runtime, and studio are absent from production builds.

## Options

```ts
miniFigma({
  enabled: true,
  route: "/__mini-figma/",
  runtimeEntry: "src/main.tsx",
  include: ["src/"],
  exclude: ["src/generated/"],
  projectName: "Component catalog",
  exportDirectory: ".mini-figma/exports",
  validationCommands: ["npm test", "npm run build"],
})
```

- `enabled`: manually disable the serve-only plugin.
- `route`: local studio/API route; defaults to `/__mini-figma/`.
- `runtimeEntry`: client entry string, regular expression, or array. Set this when Vite HTML injection does not reach the application shell.
- `include` / `exclude`: project-relative source instrumentation filters using strings or regular expressions.
- `projectName`: session/bootstrap label.
- `exportDirectory`: project-relative deterministic export parent.
- `validationCommands`: trusted server-configured validation metadata. Browser payloads cannot provide commands; the agent package does not execute them.
- `tokenFiles`: accepted for future token discovery; currently the inspector captures live CSS variables instead.
- `viewports`: project-specific presets used by the studio viewport selector and exported design evidence.

`defineMiniFigmaConfig(options)` is an identity helper for preserving literal option types. The plugin does not currently auto-load a standalone config file.

## Current workflow

- Pick an actual instrumented component on a live route and open it with one click after activating the picker.
- Edit the isolated component directly with nested selection, eight resize handles, drag/reorder, direct text editing, grouping, and a contextual property rail.
- Edit layout, size, spacing, typography, fill, border, effects, static text, and `aria-label` as preview intent.
- Record scope, responsive context, state, before/after values, and source confidence in an immutable history available through the change-details drawer.
- Undo, redo, reset, and compare without source writes.
- Copy an implementation brief. Export normalizes the studio ledger and writes the local deterministic package, with browser-downloaded JSON as an error fallback.

The canonical deterministic export and reviewed-diff contracts live in the bundled internal `@mini-figma/agent` implementation. No provider can apply a diff.

## Security

- Opaque browser node IDs; public metadata omits absolute source paths.
- Random per-server session nonce and same-origin checks for mutation requests.
- 2 MB request-body limit.
- Project-relative export paths, real-path containment, and stale base-file checks.
- Export/provider redaction and bundle integrity verification.
- No browser-supplied shell commands and no automatic source application.

Do not expose the Vite development server to untrusted networks.

## Uninstall

Remove the plugin call and import, uninstall the development dependency, and optionally delete local `.mini-figma/` exports. No application runtime shim is required.

## Limitations

- Unpublished working-name package.
- Verified only on the repository's React 19.2/Vite 8.2 example.
- No general framework adapter registry, automatic token-file discovery, persisted sessions, or automatic source application.
- The reviewed-diff provider remains a library/server contract; the studio does not yet present or apply provider diffs.

MIT licensed.
